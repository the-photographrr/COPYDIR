import os, torch
import torchaudio

# Compatibility shim: some torchaudio builds don't expose
# `list_audio_backends`/`get_audio_backend` used by SpeechBrain.
# Add lightweight fallbacks so the import succeeds.
if not hasattr(torchaudio, "list_audio_backends"):
    def _list_audio_backends():
        return ["sox_io"]
    def _get_audio_backend():
        return "sox_io"
    def _set_audio_backend(backend):
        return None
    torchaudio.list_audio_backends = _list_audio_backends
    torchaudio.get_audio_backend = _get_audio_backend
    torchaudio.set_audio_backend = _set_audio_backend

# Prefer the `sox_io` backend for robust file loading when available.
try:
    torchaudio.set_audio_backend("sox_io")
except Exception:
    pass

from speechbrain.pretrained import SpeakerRecognition

# Try alternate voice dataset location (from ~/temp_voice_data or Downloads)
DATASET = "data/patients"
ALT_DATASET = os.path.expanduser("~/temp_voice_data")
# Prefer the repo `data/patients` if it contains voice folders; otherwise
# fall back to `~/temp_voice_data` when present.
use_alt = False
if not os.path.isdir(DATASET):
    use_alt = True
else:
    # check for any patient with a 'voice' subdir
    has_voice = False
    for d in os.listdir(DATASET):
        if os.path.isdir(os.path.join(DATASET, d, "voice")):
            has_voice = True
            break
    if not has_voice and os.path.isdir(ALT_DATASET):
        use_alt = True

if use_alt:
    DATASET = ALT_DATASET
    print(f"Using voice data from: {DATASET}")

OUT_DIR = "embeddings/voices"
os.makedirs(OUT_DIR, exist_ok=True)

# HuggingFace hub compatibility shim: newer `huggingface_hub` removed
# the `use_auth_token` kwarg. Ensure calls with that kwarg still work.
try:
    import huggingface_hub
    if hasattr(huggingface_hub, "hf_hub_download"):
        _orig_hf = huggingface_hub.hf_hub_download
        def _hf_hub_download(*args, **kwargs):
            kwargs.pop("use_auth_token", None)
            return _orig_hf(*args, **kwargs)
        huggingface_hub.hf_hub_download = _hf_hub_download
except Exception:
    pass

try:
    model = SpeakerRecognition.from_hparams(
        source="speechbrain/spkrec-ecapa-voxceleb"
    )
except Exception:
    model = None
    import warnings
    warnings.warn("SpeechBrain model unavailable — using MFCC fallback embeddings")
    mfcc_transform = torchaudio.transforms.MFCC(sample_rate=16000, n_mfcc=40)

for patient in os.listdir(DATASET):
    voice_dir = os.path.join(DATASET, patient, "voice")
    if not os.path.isdir(voice_dir):
        continue

    embeddings = []

    def load_audio(path):
        try:
            return torchaudio.load(path)
        except Exception:
            # Try soundfile
            try:
                import soundfile as sf
                data, sr = sf.read(path, dtype='float32')
                import numpy as np
                import torch
                if data.ndim == 1:
                    tensor = torch.from_numpy(data).unsqueeze(0)
                else:
                    tensor = torch.from_numpy(data.T)
                return tensor, sr
            except Exception:
                # Try scipy wavfile
                try:
                    from scipy.io import wavfile
                    sr, data = wavfile.read(path)
                    import numpy as np
                    import torch
                    if data.dtype != np.float32:
                        data = data.astype('float32') / max(1, np.max(np.abs(data)))
                    if data.ndim == 1:
                        tensor = torch.from_numpy(data).unsqueeze(0)
                    else:
                        tensor = torch.from_numpy(data.T)
                    return tensor, sr
                except Exception:
                    raise

    for wav in os.listdir(voice_dir):
        audio, sr = load_audio(os.path.join(voice_dir, wav))
        if model is not None:
            emb = model.encode_batch(audio)
        else:
            # convert to mono, resample if needed
            if audio.ndim > 1:
                audio = torch.mean(audio, dim=0, keepdim=True)
            if sr != 16000:
                audio = torchaudio.functional.resample(audio, sr, 16000)
                sr = 16000
            mfcc = mfcc_transform(audio)
            emb = torch.mean(mfcc, dim=-1)
        embeddings.append(emb.squeeze())

    if embeddings:
        final = torch.mean(torch.stack(embeddings), dim=0)
        torch.save(final, f"{OUT_DIR}/{patient}.pt")
        print(f"✅ Voice trained for {patient}")
