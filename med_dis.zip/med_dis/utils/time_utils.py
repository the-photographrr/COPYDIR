from datetime import datetime
from configs.dose_times import DOSE_WINDOWS

def get_current_slot():
    hour = datetime.now().hour

    for slot, (start, end) in DOSE_WINDOWS.items():
        if start <= hour <= end:
            return slot
    return None
