#!/usr/bin/env python3
"""Face-only live authentication via webcam.

Usage examples:
  source .venv/bin/activate
  PYTHONPATH=. python3 scripts/auth_live.py

  # API JSON mode
  PYTHONPATH=. python3 scripts/auth_live.py --api
"""
import argparse
import json
import os
import time
import numpy as np
import cv2
from insightface.app import FaceAnalysis
from configs.medicine_plans import MEDICINE_PLANS
from utils.time_utils import get_current_slot
from utils.dose_lock import can_dispense
from dispense_serial import dispense
from utils import auth_cooldown

EMB_DIR = "embeddings/faces"
THRESHOLD = 0.6
CAMERA_IDX = 0
DEFAULT_COOLDOWN = 60

def load_gallery():
    names = []
    embs = []
    if not os.path.isdir(EMB_DIR):
        return names, None
    for f in os.listdir(EMB_DIR):
        if f.endswith('.npy'):
            names.append(os.path.splitext(f)[0])
            embs.append(np.load(os.path.join(EMB_DIR, f)))
    if not embs:
        return names, None
    embs = np.stack(embs)
    norms = np.linalg.norm(embs, axis=1)
    return names, (embs, norms)

def capture_frame(camera_idx=CAMERA_IDX, timeout=5.0):
    cap = cv2.VideoCapture(camera_idx)
    if not cap.isOpened():
        raise RuntimeError(f"Could not open camera {camera_idx}")
    t0 = time.time()
    while time.time() - t0 < timeout:
        ret, frame = cap.read()
        if ret:
            cap.release()
            return frame
        time.sleep(0.05)
    cap.release()
    raise RuntimeError("Timeout capturing frame")

def main(args):
    names, gallery = load_gallery()
    if gallery is None:
        print('No face embeddings found. Run train_faces.py first.')
        return
    embs, norms = gallery

    app = FaceAnalysis(name='buffalo_s')
    try:
        app.prepare(ctx_id=0)
    except Exception:
        app.prepare(ctx_id=-1)

    try:
        frame = capture_frame(camera_idx=args.camera_idx)
    except Exception as e:
        print('Capture error:', e)
        return

    faces = app.get(frame)
    if not faces:
        out = {'accepted': False, 'reason': 'no_face_detected'}
        print('No face detected')
        if args.api:
            print(json.dumps(out))
        return

    unknown_found = False
    best_overall = None

    for face in faces:
        emb = face.embedding
        emb_norm = np.linalg.norm(emb)
        sims = (embs @ emb) / (norms * emb_norm + 1e-10)
        best_idx = int(np.argmax(sims))
        best_score = float(sims[best_idx])
        best_name = names[best_idx]
        if best_score < args.face_threshold:
            unknown_found = True
        else:
            if best_overall is None or best_score > best_overall[1]:
                best_overall = (best_name, best_score)

    if unknown_found:
        out = {'accepted': False, 'reason': 'unknown_present'}
        print('Authentication rejected: unknown person present')
        if args.api:
            print(json.dumps(out))
        return

    if best_overall is None:
        out = {'accepted': False, 'reason': 'no_confident_face'}
        print('No confident match found')
        if args.api:
            print(json.dumps(out))
        return

    matched_name, score = best_overall
    user_key = matched_name.lower()

    # enforce per-user cooldown
    if not auth_cooldown.can_proceed(user_key, args.cooldown):
        out = {'accepted': False, 'reason': 'cooldown'}
        print('Authentication rejected: cooldown active for user', user_key)
        if args.api:
            print(json.dumps(out))
        return

    slot = get_current_slot()
    if not slot:
        out = {'accepted': False, 'reason': 'not_dispense_time'}
        print('Not a dispensing time')
        if args.api:
            print(json.dumps(out))
        return

    if user_key not in MEDICINE_PLANS:
        out = {'accepted': False, 'reason': 'user_not_configured'}
        print('User not configured:', user_key)
        if args.api:
            print(json.dumps(out))
        return

    plan = MEDICINE_PLANS[user_key].get(slot, [])
    if not plan:
        out = {'accepted': False, 'reason': 'no_plan'}
        print(f'No medicines for {user_key} at {slot}')
        if args.api:
            print(json.dumps(out))
        return

    if not can_dispense(user_key, slot):
        out = {'accepted': False, 'reason': 'already_dispensed'}
        print('Dose already dispensed for this slot')
        if args.api:
            print(json.dumps(out))
        return

    # success: mark cooldown and dispense
    auth_cooldown.mark(user_key)
    out = {'accepted': True, 'user': user_key, 'face_score': score, 'plan': plan}
    print(f"Authenticated: {matched_name} (score={score:.2f}) — dispensing: {plan}")
    try:
        dispense(plan)
    except Exception as e:
        print('Dispense error:', e)

    if args.api:
        print(json.dumps(out))

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--face-threshold', type=float, default=THRESHOLD)
    p.add_argument('--api', action='store_true', help='Print JSON result')
    p.add_argument('--cooldown', type=int, default=DEFAULT_COOLDOWN, help='Per-user cooldown seconds')
    p.add_argument('--camera-idx', type=int, default=CAMERA_IDX)
    args = p.parse_args()
    args.camera_idx = args.camera_idx
    main(args)
#!/usr/bin/env python3
"""Live authentication via webcam.

- Captures one frame from camera
- Detects faces; if any unknown face (similarity < threshold) is present, rejects
- If a single known face matches above threshold, proceeds to dispense for that user and current slot

Usage:
  source .venv/bin/activate
  PYTHONPATH=. python3 scripts/auth_live.py

"""
import time
import os
import numpy as np
import cv2
from insightface.app import FaceAnalysis
from datetime import datetime
from configs.medicine_plans import MEDICINE_PLANS
from utils.time_utils import get_current_slot
from utils.dose_lock import can_dispense
from dispense_serial import dispense

EMB_DIR = "embeddings/faces"
THRESHOLD = 0.6
CAMERA_IDX = 0

try:
    from utils.telegram_notify import send_telegram
except Exception:
    send_telegram = None


def load_gallery():
    names = []
    embs = []
    if not os.path.isdir(EMB_DIR):
        return names, None
    for f in os.listdir(EMB_DIR):
        if f.endswith('.npy'):
            names.append(os.path.splitext(f)[0])
            embs.append(np.load(os.path.join(EMB_DIR, f)))
    if not embs:
        return names, None
    embs = np.stack(embs)
    norms = np.linalg.norm(embs, axis=1)
    return names, (embs, norms)


def capture_frame(camera_idx=CAMERA_IDX, timeout=5.0):
    cap = cv2.VideoCapture(camera_idx)
    if not cap.isOpened():
        raise RuntimeError(f"Could not open camera {camera_idx}")
    t0 = time.time()
    while time.time() - t0 < timeout:
        ret, frame = cap.read()
        if ret:
            cap.release()
            return frame
        time.sleep(0.05)
    cap.release()
    raise RuntimeError("Timeout capturing frame")


def main():
    names, gallery = load_gallery()
    if gallery is None:
        print('No face embeddings found. Run train_faces.py first.')
        return
    embs, norms = gallery

    app = FaceAnalysis(name='buffalo_s')
    try:
        app.prepare(ctx_id=0)
    except Exception:
        app.prepare(ctx_id=-1)

    try:
        frame = capture_frame()
    except Exception as e:
        print('Capture error:', e)
        return

    faces = app.get(frame)
    if not faces:
        print('No face detected')
        return

    unknown_found = False
    best_overall = None

    for face in faces:
        emb = face.embedding
        emb_norm = np.linalg.norm(emb)
        sims = (embs @ emb) / (norms * emb_norm + 1e-10)
        best_idx = int(np.argmax(sims))
        best_score = float(sims[best_idx])
        best_name = names[best_idx]
        if best_score < THRESHOLD:
            unknown_found = True
        else:
            if best_overall is None or best_score > best_overall[1]:
                best_overall = (best_name, best_score)

    if unknown_found:
        print('Authentication rejected: unknown person present')
        if send_telegram:
            try:
                send_telegram('⚠️ Authentication rejected: unknown person present')
            except Exception:
                pass
        return

    if best_overall is None:
        print('No confident match found')
        return

    matched_name, score = best_overall
    user_key = matched_name.lower()

    slot = get_current_slot()
    if not slot:
        print('Not a dispensing time')
        return

    if user_key not in MEDICINE_PLANS:
        print('User not configured:', user_key)
        return

    plan = MEDICINE_PLANS[user_key].get(slot, [])
    if not plan:
        print(f'No medicines for {user_key} at {slot}')
        return

    if not can_dispense(user_key, slot):
        print('Dose already dispensed for this slot')
        return

    print(f"Authenticated: {matched_name} (score={score:.2f}) — dispensing: {plan}")
    try:
        dispense(plan)
    except Exception as e:
        print('Dispense error:', e)


if __name__ == '__main__':
    main()
