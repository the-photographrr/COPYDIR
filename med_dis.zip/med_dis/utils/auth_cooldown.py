import json
import os
import time

COOLDOWN_FILE = "state/auth_cooldown.json"

def load_cooldowns():
    if not os.path.exists(COOLDOWN_FILE):
        return {}
    with open(COOLDOWN_FILE, 'r') as f:
        try:
            return json.load(f)
        except Exception:
            return {}

def save_cooldowns(d):
    os.makedirs(os.path.dirname(COOLDOWN_FILE), exist_ok=True)
    with open(COOLDOWN_FILE, 'w') as f:
        json.dump(d, f)

def can_proceed(user, cooldown_sec):
    d = load_cooldowns()
    last = d.get(user)
    now = time.time()
    if last and now - last < cooldown_sec:
        return False
    return True

def mark(user):
    d = load_cooldowns()
    d[user] = time.time()
    save_cooldowns(d)
