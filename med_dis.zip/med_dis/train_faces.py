import os, cv2, numpy as np
from insightface.app import FaceAnalysis

DATASET = "data/patients"
OUT_DIR = "embeddings/faces"
os.makedirs(OUT_DIR, exist_ok=True)

app = FaceAnalysis(name="buffalo_s")
try:
    # try GPU first
    app.prepare(ctx_id=0)
except Exception:
    # fallback to CPU
    print("⚠️ GPU init failed, falling back to CPU (ctx_id=-1)")
    app.prepare(ctx_id=-1)

for patient in os.listdir(DATASET):
    patient_path = os.path.join(DATASET, patient)
    # prefer a 'face' subdirectory, otherwise use patient directory
    face_dir = os.path.join(patient_path, "face")
    if not os.path.isdir(face_dir):
        face_dir = patient_path

    embeddings = []

    for img_name in os.listdir(face_dir):
        img_path = os.path.join(face_dir, img_name)
        if not os.path.isfile(img_path):
            continue
        img = cv2.imread(img_path)
        if img is None:
            continue
        faces = app.get(img)
        if faces:
            embeddings.append(faces[0].embedding)

    if embeddings:
        mean_emb = np.mean(embeddings, axis=0)
        np.save(os.path.join(OUT_DIR, patient + ".npy"), mean_emb)
        print(f"✅ Face trained for {patient}")
