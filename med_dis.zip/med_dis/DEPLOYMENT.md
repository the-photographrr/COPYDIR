# med_dis Deployment Guide

## Quick Start (Pi)

### 1. Unzip on Raspberry Pi
```bash
unzip med_dis.zip
cd med_dis
chmod +x setup_pi.sh
```

### 2. Run Setup
```bash
sudo ./setup_pi.sh
```

This installs OS packages, Python venv, pip requirements, and systemd timer.

### 3. Verify Deployment
```bash
python3 verify_pi_deployment.py
```

### 4. Configure Medicine Plans
Edit `configs/medicine_plans.py` with your patient names and schedules.

### 5. Start the Timer
```bash
sudo systemctl enable med_dis.timer
sudo systemctl start med_dis.timer

# Monitor logs
sudo journalctl -u med_dis -f
```

## How It Works

### Interactive Auth & Dispense

During a dispensing time window, SSH into your Pi and run:

```bash
cd ~/med_dis
./.venv_pi/bin/python auth_and_dispense.py
```

This captures face → matches voice → dispenses medicines.

### Automated Monitoring

The systemd timer runs `med_dis_service.py` every minute:
- Checks if it's a dispensing time
- Logs "DISPENSING TIME: [slot]"
- Prompts to run `auth_and_dispense.py`

Monitor logs:
```bash
sudo journalctl -u med_dis -f
```

## Troubleshooting

**Timer won't start:**
```bash
sudo systemctl status med_dis.timer
sudo journalctl -u med_dis -n 50
```

**Arduino access denied:**
```bash
sudo usermod -a -G dialout pi
# Log out and back in
```

**Camera not found:**
```bash
sudo raspi-config  # Enable Camera
ls -la /dev/video*
```

**Null bytes in files:**
```bash
python3 verify_pi_deployment.py
# Re-copy from workstation if corrupted
```

## Customization

**Dose times:** `configs/dose_times.py`  
**Medicine schedules:** `configs/medicine_plans.py`  
**Servo calibration:** `scripts/test_dispense.py --port /dev/ttyUSB0 calibrate A 45`

---

For full documentation, see README.md
