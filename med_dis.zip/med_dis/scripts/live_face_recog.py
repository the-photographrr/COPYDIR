#!/usr/bin/env python3
import os
import time
import numpy as np
import cv2
from insightface.app import FaceAnalysis

EMB_DIR = "embeddings/faces"
THRESHOLD = 0.6
NOTIFY_UNKNOWN = True
NOTIFY_COOLDOWN_SEC = 60
_last_notify_time = 0
try:
    from utils.telegram_notify import send_telegram
except Exception:
    send_telegram = None

def load_gallery():
    names = []
    embs = []
    if not os.path.isdir(EMB_DIR):
        return names, None
    for f in os.listdir(EMB_DIR):
        if f.endswith('.npy'):
            names.append(os.path.splitext(f)[0])
            embs.append(np.load(os.path.join(EMB_DIR, f)))
    if not embs:
        return names, None
    embs = np.stack(embs)  # (N, D)
    norms = np.linalg.norm(embs, axis=1)
    return names, (embs, norms)

def main(camera_idx=0, threshold=THRESHOLD):
    names, gallery = load_gallery()
    if gallery is None:
        print('No face embeddings found in', EMB_DIR)
        return
    embs, norms = gallery

    app = FaceAnalysis(name='buffalo_s')
    try:
        app.prepare(ctx_id=0)
    except Exception:
        app.prepare(ctx_id=-1)

    cap = cv2.VideoCapture(camera_idx)
    if not cap.isOpened():
        print('Could not open camera', camera_idx)
        return

    print('Press q to quit. Threshold:', threshold)
    while True:
        ret, frame = cap.read()
        if not ret:
            time.sleep(0.1)
            continue

        faces = app.get(frame)
        unknown_found = False
        if faces:
            for face in faces:
                emb = face.embedding
                emb_norm = np.linalg.norm(emb)
                sims = (embs @ emb) / (norms * emb_norm + 1e-10)
                best_idx = int(np.argmax(sims))
                best_score = float(sims[best_idx])
                best_name = names[best_idx]

                text = f"{best_name} {best_score:.2f}"
                if best_score >= threshold:
                    color = (0, 200, 0)
                else:
                    color = (0, 0, 200)
                    unknown_found = True

                # Draw bbox if available
                if hasattr(face, 'bbox') and face.bbox is not None:
                    x1, y1, x2, y2 = [int(v) for v in face.bbox]
                    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
                    cv2.putText(frame, text, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
                else:
                    cv2.putText(frame, text, (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 1.0, color, 2)

        # If any unknown face detected, optionally notify (cooldown)
        if unknown_found:
            cv2.putText(frame, 'UNKNOWN PERSON DETECTED', (20, 80), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0,0,255), 3)
            if NOTIFY_UNKNOWN and send_telegram:
                try:
                    import time
                    now = time.time()
                    if now - _last_notify_time > NOTIFY_COOLDOWN_SEC:
                        send_telegram('⚠️ Unknown person detected on camera')
                        _last_notify_time = now
                except Exception:
                    pass

        cv2.imshow('Live Face Recognition', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
