from configs.medicine_plans import MEDICINE_PLANS
from utils.time_utils import get_current_slot
from utils.dose_lock import can_dispense
from dispense_serial import dispense

# Result from face + voice auth
user = "adarsh"   # example

slot = get_current_slot()

if not slot:
    print("❌ Not a dispensing time")
    exit()

if user not in MEDICINE_PLANS:
    print("❌ User not configured")
    exit()

plan = MEDICINE_PLANS[user].get(slot, [])

if not plan:
    print(f"ℹ️ No medicines for {user} at {slot}")
    exit()

if not can_dispense(user, slot):
    print("⛔ Dose already dispensed for this slot")
    exit()

print(f"👤 {user} | ⏰ {slot} | 💊 {plan}")
dispense(plan)
