#!/usr/bin/env python3
"""
Service wrapper for med_dis
- Non-interactive: just checks if it's a dispensing time
- Logs status to files
- Exits cleanly (allows systemd timer to call it periodically)
- For interactive auth+dispense, run: python3 auth_and_dispense.py manually
"""

import os
import sys
import traceback
from datetime import datetime

# Add project dir to path
sys.path.insert(0, os.path.dirname(__file__))

LOG_FILE = "med_dis.log"
ERR_FILE = "med_dis.err"

def log_msg(msg, is_error=False):
    """Log message to stdout and file."""
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    full_msg = f"[{ts}] {msg}"
    print(full_msg)
    f = ERR_FILE if is_error else LOG_FILE
    try:
        with open(f, 'a') as fp:
            fp.write(full_msg + '\n')
    except Exception:
        pass  # If can't write log, just continue

def main():
    """Check if it's a dispensing time. Log status and exit."""
    try:
        from utils.time_utils import get_current_slot
        from configs.medicine_plans import MEDICINE_PLANS
        
        slot = get_current_slot()
        if slot:
            log_msg(f"✓ DISPENSING TIME: {slot}")
            log_msg("Run: python3 auth_and_dispense.py")
            return 0
        else:
            log_msg(f"✗ Not a dispensing time yet. Next check: systemd timer")
            return 0  # Exit cleanly; systemd timer will call us again
    except Exception as e:
        log_msg(f"ERROR: {e}", is_error=True)
        log_msg(traceback.format_exc(), is_error=True)
        return 1

if __name__ == '__main__':
    sys.exit(main())
