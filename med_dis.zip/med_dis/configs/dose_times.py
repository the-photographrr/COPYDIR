DOSE_WINDOWS = {
    "morning": (8, 11),    
    "afternoon": (12, 16),
    "night": (22, 23)      
}
