from datetime import datetime
from configs.medicine_plans import MEDICINE_PLANS
from configs.dose_times import DOSE_WINDOWS
from utils.telegram_notify import send_telegram
from utils.dose_lock import load_state, save_state

def check_skipped_doses():
    now = datetime.now()
    today = now.strftime("%Y-%m-%d")
    hour = now.hour

    state = load_state()

    for user, plans in MEDICINE_PLANS.items():
        for slot, meds in plans.items():
            start, end = DOSE_WINDOWS[slot]

            # Slot window already passed
            if hour > end:
                last = state.get(user, {}).get(slot)

                if last != today:
                    msg = (
                        f"⚠️ MEDICINE SKIPPED\n\n"
                        f"👤 Patient: {user}\n"
                        f"⏰ Slot: {slot}\n"
                        f"💊 Medicines: {', '.join(meds)}\n"
                        f"📅 Date: {today}"
                    )
                    send_telegram(msg)

                    # Mark as notified and block further dispensing for today
                    # Use structured state so we can track status and notification
                    state.setdefault(user, {})[slot] = {
                        "date": today,
                        "status": "skipped",
                        "notified": True
                    }
                    save_state(state)
