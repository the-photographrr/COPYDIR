import json, os
from datetime import datetime

STATE_FILE = "state/last_dispense.json"

def load_state():
    if not os.path.exists(STATE_FILE):
        return {}
    with open(STATE_FILE, "r") as f:
        return json.load(f)

def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f)

def can_dispense(user, slot):
    """Return True and record dispense if slot not already handled today.

    The state supports two formats for backward compatibility:
    - legacy: state[user][slot] == "YYYY-MM-DD"
    - structured: state[user][slot] == {"date": "YYYY-MM-DD", "status": "dispensed"|"skipped", ...}
    """
    state = load_state()
    today = datetime.now().strftime("%Y-%m-%d")

    last = state.get(user, {}).get(slot)

    # structured entry
    if isinstance(last, dict):
        if last.get("date") == today and last.get("status") in ("dispensed", "skipped"):
            return False
    else:
        # legacy string date
        if last == today:
            return False

    state.setdefault(user, {})[slot] = {"date": today, "status": "dispensed"}
    save_state(state)
    return True
