import serial
import time

ser = serial.Serial('/dev/ttyUSB0', 9600, timeout=2)
time.sleep(2)  # Nano reset time

def dispense(plan):
    """
    plan = ["PILL_A", "PILL_C", "LIQUID"]
    """
    cmd = "DISPENSE:" + ",".join(plan) + "\n"
    ser.write(cmd.encode())

    resp = ser.readline().decode().strip()
    print("Nano:", resp)

# Example
dispense(["PILL_A", "PILL_C", "LIQUID"])
