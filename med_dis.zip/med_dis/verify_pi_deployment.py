#!/usr/bin/env python3
"""
Deployment verification script for med_dis on Raspberry Pi.
Run this on the Pi to verify all required files are present and uncorrupted.
"""

import os
import sys

REQUIRED_FILES = {
    # Core Python scripts
    'auth_and_dispense.py': 'Main auth + dispense orchestrator',
    'train_faces.py': 'Face embedding training',
    'train_voices.py': 'Voice embedding training',
    'dispense_serial.py': 'Serial communication with Arduino',
    
    # Config files
    'configs/medicine_plans.py': 'Medicine schedules per patient',
    'configs/dose_times.py': 'Dose window times',
    
    # Utility modules
    'utils/__init__.py': 'Utils package (can be empty)',
    'utils/time_utils.py': 'Time slot calculations',
    'utils/dose_lock.py': 'Dose state management',
    'utils/auth_cooldown.py': 'Auth cooldown logic',
    'utils/telegram_notify.py': 'Telegram notifications',
    'utils/skip_checker.py': 'Skip dose logic',
    
    # Scripts
    'scripts/__init__.py': 'Scripts package (can be empty)',
    'scripts/test_dispense.py': 'Host test script for Arduino',
    'scripts/live_face_recog.py': 'Live face recognition',
    'scripts/auth_live.py': 'Live auth demo',
    'scripts/migrate_state.py': 'State migration',
    
    # Data directories (may be empty on Pi initially)
    'data/patients': 'Patient face/voice data directory',
    'embeddings/faces': 'Face embeddings directory',
    'embeddings/voices': 'Voice embeddings directory',
    'state': 'State directory for dose tracking',
    
    # Setup and service files
    'setup_pi.sh': 'Pi setup script',
    'med_dis.service': 'Systemd service template',
    'requirements-pi.txt': 'Pi-specific requirements',
    'requirements.txt': 'Full requirements',
}

def check_file(path, is_dir=False):
    """Check if a file or directory exists and is not corrupt (for .py files)."""
    if os.path.isdir(path):
        return True, f"✓ dir exists"
    if os.path.isfile(path):
        # Check for null bytes in .py files
        if path.endswith('.py'):
            try:
                with open(path, 'rb') as f:
                    data = f.read()
                    if b'\x00' in data:
                        return False, f"✗ contains null bytes (corrupt)"
                return True, f"✓ file OK"
            except Exception as e:
                return False, f"✗ read error: {e}"
        return True, f"✓ file exists"
    return False, f"✗ missing"

def main():
    print("=" * 70)
    print("med_dis Deployment Verification")
    print("=" * 70)
    
    missing = []
    corrupt = []
    ok = []
    
    for path, desc in REQUIRED_FILES.items():
        exists, msg = check_file(path)
        status = msg
        if exists:
            ok.append((path, desc))
        else:
            if '✗' in msg:
                if 'corrupt' in msg:
                    corrupt.append((path, msg))
                else:
                    missing.append((path, msg))
        print(f"{status:20} {path:35} ({desc})")
    
    print("=" * 70)
    print(f"OK: {len(ok)}, MISSING: {len(missing)}, CORRUPT: {len(corrupt)}")
    print("=" * 70)
    
    if corrupt:
        print("\n⚠ CORRUPT FILES (contain null bytes):")
        for path, msg in corrupt:
            print(f"  - {path}: {msg}")
        print("\nFix: Re-copy these files from your workstation using:")
        for path, _ in corrupt:
            print(f"  scp /path/to/local/{path} pi@raspberrypi:~/med_dis/{path}")
    
    if missing:
        print("\n⚠ MISSING FILES:")
        for path, msg in missing:
            if not path.endswith('/'):
                print(f"  - {path}")
        print("\nFix: Copy missing files from your workstation using:")
        print("  scp -r /path/to/local/med_dis pi@raspberrypi:~/")
        print("Or run full deploy from the workstation:")
        print("  rsync -av /path/to/local/med_dis/ pi@raspberrypi:~/med_dis/")
    
    if ok:
        print(f"\n✓ {len(ok)} files OK")
    
    if missing or corrupt:
        sys.exit(1)
    else:
        print("\n✓ All required files present and OK!")
        sys.exit(0)

if __name__ == '__main__':
    main()
