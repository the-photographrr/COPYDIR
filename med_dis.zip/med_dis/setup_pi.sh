#!/usr/bin/env bash
set -euo pipefail

# Raspberry Pi setup script for med_dis
# Run as the user that will run the service (typically 'pi')
# Usage: sudo ./setup_pi.sh or ./setup_pi.sh (will use sudo for apt)

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV_DIR="$PROJECT_DIR/.venv_pi"
REQ_FILE="$PROJECT_DIR/requirements-pi.txt"
SERVICE_FILE="/etc/systemd/system/med_dis.service"

echo "Project dir: $PROJECT_DIR"

if [ "$(id -u)" -ne 0 ]; then
  echo "This script will use sudo for system operations. You may be prompted for your password."
fi

# Update and install OS packages
sudo apt update
sudo apt install -y python3-venv python3-pip git build-essential libatlas-base-dev \
    libsndfile1 ffmpeg libavcodec-dev libavformat-dev libavutil-dev libsox-dev libsox-fmt-all \
    libasound2-dev pkg-config

# Optional helpful tools
sudo apt install -y vim htop screen

# Create virtualenv
if [ ! -d "$VENV_DIR" ]; then
  python3 -m venv "$VENV_DIR"
fi

# Upgrade pip and install requirements
"$VENV_DIR/bin/pip" install --upgrade pip setuptools wheel
if [ -f "$REQ_FILE" ]; then
  echo "Installing pip requirements from $REQ_FILE"
  "$VENV_DIR/bin/pip" install -r "$REQ_FILE"
else
  echo "Warning: $REQ_FILE not found. Skipping pip install."
fi

# Ensure current user (or 'pi') is in dialout so it can access /dev/ttyUSB0
USER_TO_ADD="${SUDO_USER:-$(whoami)}"
if ! groups "$USER_TO_ADD" | grep -q dialout; then
  echo "Adding $USER_TO_ADD to dialout group (may need logout/login)"
  sudo usermod -a -G dialout "$USER_TO_ADD"
fi

# Install systemd service file (use project path)
cat <<EOF | sudo tee "$SERVICE_FILE" > /dev/null
[Unit]
Description=Med dispenser auth+dispense service
After=network.target

[Service]
Type=simple
User=${SUDO_USER:-$(whoami)}
WorkingDirectory=$PROJECT_DIR
ExecStart=$VENV_DIR/bin/python $PROJECT_DIR/auth_and_dispense.py
Restart=on-failure
RestartSec=5s
StandardOutput=append:$PROJECT_DIR/med_dis.log
StandardError=append:$PROJECT_DIR/med_dis.err

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable med_dis.service

echo "Setup complete. You can start the service with:"
echo "  sudo systemctl start med_dis.service"

echo "Logs: $PROJECT_DIR/med_dis.log and $PROJECT_DIR/med_dis.err"

echo "Notes:"
echo "- If you use the Raspberry Pi camera, ensure it's enabled (libcamera)."
echo "- If you installed audio packages, reboot may be required."
echo "- After adding your user to 'dialout', log out and back in to apply group changes."
