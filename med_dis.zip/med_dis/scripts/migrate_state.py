#!/usr/bin/env python3
from utils.dose_lock import load_state, save_state

"""Migrate legacy state values to structured format.

Legacy format:
  state[user][slot] = "YYYY-MM-DD"

New format:
  state[user][slot] = {"date": "YYYY-MM-DD", "status": "dispensed"}

Run once before deploying updated code.
"""

def migrate():
    s = load_state()
    changed = False

    for user, slots in list(s.items()):
        for slot, val in list(slots.items()):
            if isinstance(val, str):
                s[user][slot] = {"date": val, "status": "dispensed"}
                changed = True

    if changed:
        save_state(s)
        print("Migration applied: legacy string dates converted to structured entries.")
    else:
        print("No migration needed.")

if __name__ == '__main__':
    migrate()
