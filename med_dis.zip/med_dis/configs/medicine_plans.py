MEDICINE_PLANS = {

    "adarsh": {
        "morning":   ["PILL_A", "LIQUID"],
        "night":     ["PILL_B"]
    },

    "nandana": {
        "morning":   ["PILL_A", "PILL_C"],
        "afternoon": ["LIQUID"]
    },

    "nitha": {
        "morning":   ["PILL_B"],
        "night":     ["PILL_B", "LIQUID"]
    },

    "swetha": {
        "morning":   ["PILL_A", "PILL_B", "PILL_C"]
    }
}
