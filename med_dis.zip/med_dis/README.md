# Medicine Dispenser: Complete Setup & Deployment Guide

## Overview
A face/voice-biometric medicine dispenser system for automated patient medication dispensing with Telegram alerts and cooldown protection.

## Quick Start (Development)

### Prerequisites
- Python 3.8+
- Webcam (for face recognition)
- Microphone (optional, for voice verification)
- Arduino Nano (for hardware control)

### 1. Clone & Setup Environment
```bash
cd /home/arun/Documents/med_dis
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 2. Configure Telegram (Optional)
Edit `utils/telegram_notify.py`:
```python
BOT_TOKEN = "your_telegram_bot_token"
CHAT_ID = "your_chat_id"
```

### 3. Prepare Patient Data
Ensure folder structure exists:
```
data/patients/
├── ADARSH/
│   ├── 1.jpg, 2.jpg, ...  (face training images)
│   └── voice/ (optional)
│       └── 1.wav, 2.wav, ...  (voice training samples)
├── NANDANA/
├── NITHA/
└── swetha/
```

### 4. Train Face Embeddings
```bash
PYTHONPATH=. python3 train_faces.py
# Output: embeddings/faces/ADARSH.npy, etc.
```

### 5. Train Voice Embeddings (Optional)
```bash
PYTHONPATH=. python3 train_voices.py
# Output: embeddings/voices/ADARSH.pt, etc.
```

### 6. Run Live Authentication
```bash
PYTHONPATH=. python3 scripts/auth_live.py
# Or API mode:
PYTHONPATH=. python3 scripts/auth_live.py --api
```

### 7. Run Live Camera Monitoring (Detect Unknown Faces)
```bash
PYTHONPATH=. python3 scripts/live_face_recog.py
```

---

## Raspberry Pi Deployment

### Hardware Requirements
- Raspberry Pi 4B (2GB+ RAM)
- USB Webcam
- USB Microphone (optional)
- Arduino Nano (via USB serial)
- Power supply (5V 3A+)

### Pi Setup Steps

#### 1. Install OS & Dependencies
```bash
# On Pi, install system packages
sudo apt-get update
sudo apt-get install -y python3-dev python3-pip python3-venv libopenblas0 libjasper1
sudo apt-get install -y libatlas-base-dev libjasper-dev libtiff5 libjasper1 libharfbuzz0b libwebp6 libtiff5
sudo apt-get install -y libhdf5-dev libharfbuzz0b libwebp6 libtiff5 libjasper1
```

#### 2. Clone Project
```bash
cd ~
git clone <your-repo-url> med_dis
cd med_dis
```

#### 3. Create Virtual Environment
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip setuptools wheel
```

#### 4. Install Dependencies (Pi-optimized)
For Pi with limited resources, use prebuilt wheels where possible:
```bash
# Install PyTorch + OpenCV (prebuilt for ARM)
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
pip install opencv-python-headless

# Install remaining deps
pip install numpy insightface onnxruntime requests tqdm

# Optional: voice (if you have space)
pip install speechbrain
```

Or use the requirements file (may take 30+ min on Pi):
```bash
pip install -r requirements.txt
```

#### 5. Copy Embeddings to Pi
```bash
# On your dev machine:
scp -r embeddings/ pi@<pi-ip>:/home/pi/med_dis/

# On Pi:
cd ~/med_dis
mkdir -p state
```

#### 6. Configure Serial Port (Arduino)
```bash
# Check if Arduino is connected
ls -la /dev/ttyUSB*

# Allow Pi user to access serial
sudo usermod -a -G dialout $USER
# Log out and back in
```

#### 7. Run Auth Script (Cron/Systemd)

**Option A: Systemd Service**
```bash
# Create /etc/systemd/system/med-dispenser.service
sudo nano /etc/systemd/system/med-dispenser.service
```
Add:
```ini
[Unit]
Description=Medicine Dispenser
After=network.target

[Service]
Type=simple
User=pi
WorkingDirectory=/home/pi/med_dis
ExecStart=/home/pi/med_dis/.venv/bin/python3 scripts/auth_live.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Enable & start:
```bash
sudo systemctl daemon-reload
sudo systemctl enable med-dispenser.service
sudo systemctl start med-dispenser.service
sudo systemctl status med-dispenser.service
```

**Option B: Cron Job (Run every minute)**
```bash
crontab -e
```
Add:
```cron
* * * * * cd /home/pi/med_dis && /home/pi/med_dis/.venv/bin/python3 -c "from scripts.auth_live import main; main(__import__('argparse').Namespace(face_threshold=0.6, api=False, cooldown=60, camera_idx=0))" >> /tmp/med_dispenser.log 2>&1
```

---

## Key Files & Functionality

| File | Purpose |
|------|---------|
| `auth.py` | Legacy: static user auth (for Arduino) |
| `scripts/auth_live.py` | **Main**: face + cooldown + dispense |
| `scripts/live_face_recog.py` | Live webcam monitoring (detect unknowns) |
| `train_faces.py` | Generate face embeddings from JPEG images |
| `train_voices.py` | Generate voice embeddings from WAV files |
| `utils/dose_lock.py` | State management (dispense once per slot) |
| `utils/auth_cooldown.py` | Per-user cooldown tracking |
| `utils/skip_checker.py` | Detect skipped doses + notify |
| `utils/telegram_notify.py` | Send Telegram alerts |
| `configs/dose_times.py` | Morning/afternoon/night windows |
| `configs/medicine_plans.py` | Patient → medicines mapping |

---

## Configuration

### Thresholds
Edit script files to adjust:
```python
THRESHOLD = 0.6  # Face match confidence (0–1)
VOICE_THRESHOLD = 0.5  # Voice match confidence
DEFAULT_COOLDOWN = 60  # Seconds between same-user dispenses
```

### Telegram Setup
1. Create a Telegram bot: [BotFather](https://t.me/botfather)
2. Get your chat ID: message the bot and fetch from API
3. Update `utils/telegram_notify.py`:
   ```python
   BOT_TOKEN = "123456:ABC..."
   CHAT_ID = "987654321"
   ```

### Time Windows
Edit `configs/dose_times.py`:
```python
DOSE_WINDOWS = {
    "morning": (5, 11),
    "afternoon": (12, 16),
    "night": (18, 22),
}
```

### Patient Plans
Edit `configs/medicine_plans.py`:
```python
MEDICINE_PLANS = {
    "adarsh": {
        "morning": ["PILL_A", "LIQUID"],
        "night": ["PILL_B"],
    },
    ...
}
```

---

## Troubleshooting

### Pi Performance
- Face detection is slow (~2–5 sec per frame on Pi 4)
- Consider reducing camera resolution or running on GPU-enabled Pi (not available)
- Use `--api` mode for headless operation

### Camera Not Found
```bash
# Check camera:
ls -la /dev/video*
# Test with:
libcamera-hello --timeout 2000  # (Pi OS, newer)
```

### Serial Port Issues
```bash
# Check Arduino:
ls -la /dev/ttyUSB*
# Check permissions:
groups $USER
# If missing dialout:
sudo usermod -a -G dialout $USER
```

### Low Memory (Pi)
- Stop other services: `sudo systemctl stop bluetooth`
- Use CPU-only inference
- Reduce frame resolution in `live_face_recog.py`

---

## API Mode (JSON Output)
For integration with external services:
```bash
PYTHONPATH=. python3 scripts/auth_live.py --api
```
Output:
```json
{
  "accepted": true,
  "user": "adarsh",
  "face_score": 0.9665,
  "plan": ["PILL_A", "LIQUID"]
}
```

---

## Backups & Logs

```bash
# Logs
tail -f /tmp/med_dispenser.log

# State backup
cp state/last_dispense.json state/last_dispense.json.bak
cp state/auth_cooldown.json state/auth_cooldown.json.bak

# Embeddings backup
tar -czf embeddings.tar.gz embeddings/
```

---

## Future Enhancements
- [ ] Voice verification (two-factor)
- [ ] Web dashboard (Flask)
- [ ] Mobile app integration
- [ ] Database logging (SQLite)
- [ ] IR/RFID fallback
