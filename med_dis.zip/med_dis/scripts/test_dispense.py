import sys
import time
import serial
import argparse

# Simple XOR checksum to match Arduino's compute_chksum

def checksum(s: str) -> int:
    x = 0
    for ch in s:
        x ^= ord(ch)
    return x


def send_command(ser, payload, add_checksum=True, wait_ack=True, timeout=5):
    line = payload
    if add_checksum:
        chk = checksum(line)
        line = f"{line}#{chk:02X}"
    ser.write((line + "\n").encode())
    ser.flush()
    start = time.time()
    responses = []
    while time.time() - start < timeout:
        if ser.in_waiting:
            r = ser.readline().decode(errors='ignore').strip()
            print("<--", r)
            responses.append(r)
            # stop on DONE or ABORTED or NO_ACTION
            if r.startswith("ACK:") or r.startswith("DONE") or r.startswith("ABORTED") or r in ("OK","STOPPED","BAD_CHKSUM"):
                break
        time.sleep(0.05)
    return responses


def main():
    parser = argparse.ArgumentParser(description='Test dispenser host script')
    parser.add_argument('--port', '-p', required=True)
    sub = parser.add_subparsers(dest='cmd')

    calib = sub.add_parser('calibrate', help='Move a servo to an angle for calibration')
    calib.add_argument('servo', choices=['A','B','C'], help='Servo letter')
    calib.add_argument('angle', type=int, help='Angle 0-180')

    disp = sub.add_parser('dispense', help='Send a dispense command')
    disp.add_argument('--id', '-i', default=None, help='Optional command id')
    disp.add_argument('items', help='Comma-separated items, e.g. PILL_A,PILL_B,LIQUID')

    args = parser.parse_args()
    ser = serial.Serial(args.port, 9600, timeout=1)
    time.sleep(2)

    # drain
    while ser.in_waiting:
        print("<--", ser.readline().decode().strip())

    if args.cmd == 'calibrate':
        srv = args.servo
        ang = args.angle
        name = f"SERVO_{srv}"
        payload = f"MOVE:{name}:{ang}"
        print("-->", payload)
        send_command(ser, payload, add_checksum=True)
    elif args.cmd == 'dispense':
        cid = args.id
        items = args.items
        if cid:
            payload = f"DISPENSE:{cid}:{items}"
        else:
            payload = f"DISPENSE:{items}"
        print("-->", payload)
        send_command(ser, payload, add_checksum=True, timeout=15)
    else:
        parser.print_help()

if __name__ == '__main__':
    main()
